package com.example;

public final class ExampleMod {
    public static final String MOD_ID = "example_mod";

    public static void init() {
        // Write common init code here.
    }
}
